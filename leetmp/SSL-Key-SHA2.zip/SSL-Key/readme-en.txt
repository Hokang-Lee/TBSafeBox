-----------------------------------------------------       2015.12.09
The making procedure by the self signature of "certificate and private key"
-----------------------------------------------------
-------------------------------------------------------------------
Step 1)
 It executes CERTIFICATE.BAT.
 CERTIFICATE.BAT does the following processing.
  1.The making of a self CA.
  2.The making of "private key and the application for registration".
  3.The issue of "certificate" by the CA.
    * When inputting a necessary item, "the certificate and private key" is made.
Step 2)
  4.It sets "certificate and private key" to E-POST Mail Server".
  5.The specification of the IP address for SMTP over SSL/the port (Client - Server)
  6.The specification of the IP address for POP3 over SSL/the port (Client - Server)
  7.The specification of the IP address for SMTP over SSL/the port (Server - Server)
-------------------------------------------------------------------

-------------------------------------------------------------------
1.The making of a self CA.
-------------------------------------------------------------------
openssl req -config openssl.cnf -new -nodes -keyout cakey.pem -x509 -out cacert.pem

Using configuration from openssl.cnf
Loading 'screen' into random state - done
Generating a 2048 bit RSA private key
..++++++++++++
....++++++++++++
writing new private key to 'key.pem'
-----
You are about to be asked to enter information that will be incorporated
into your certificate request.
What you are about to enter is what is called a Distinguished Name or a DN.
There are quite a few fields but you can leave some blank
For some fields there will be a default value,
If you enter '.', the field will be left blank.
-----
Country Name (2 letter code) [JP]:JP
State or Province Name (full name) [Some-State]:Saitama
Locality Name (eg, city) []:Kasukabe
Organization Name (eg, company) [Internet Widgits Pty Ltd]:ACCESS
Organizational Unit Name (eg, section) []:Postmaster
Common Name (eg, YOUR name) []:mail.e-postinc.jp
Email Address []:
-------------------------------------------------------------------

-------------------------------------------------------------------
2.The making of "private key and the application for registration".
-------------------------------------------------------------------
openssl req -config openssl.cnf -new -nodes -newkey rsa:2048 -keyout mykey.pem -out myreq.pem 

Using configuration from openssl.cnf
Loading 'screen' into random state - done
Generating a 2048 bit RSA private key
...++++++++++++
.++++++++++++
writing new private key to 'mykey.pem'
-----
You are about to be asked to enter information that will be incorporated
into your certificate request.
What you are about to enter is what is called a Distinguished Name or a DN.
There are quite a few fields but you can leave some blank
For some fields there will be a default value,
If you enter '.', the field will be left blank.
-----
Country Name (2 letter code) [JP]:JP
State or Province Name (full name) [Some-State]:Saitama
Locality Name (eg, city) []:Kasukabe
Organization Name (eg, company) [Internet Widgits Pty Ltd]:ACCESS
Organizational Unit Name (eg, section) []:Postmaster
Common Name (eg, YOUR name) []:mail.e-postinc.jp
Email Address []:

Please enter the following 'extra' attributes
to be sent with your certificate request
A challenge password []:
An optional company name []:
-------------------------------------------------------------------

-------------------------------------------------------------------
3.The issue of "certificate" by the CA.
-------------------------------------------------------------------
openssl ca -config openssl.cnf -in myreq.pem -keyfile cakey.pem -cert cacert.pem -out mycert.pem

Using configuration from openssl.cnf
Loading 'screen' into random state - done
Check that the request matches the signature
Signature ok
The Subjects Distinguished Name is as follows
countryName           :PRINTABLE:'JP'
stateOrProvinceName   :PRINTABLE:'Saitama'
localityName          :PRINTABLE:'Kasukabe'
organizationName      :PRINTABLE:'ACCESS'
organizationalUnitName:PRINTABLE:'Postmaster'
commonName            :PRINTABLE:'mail.e-postinc.jp'
Certificate is to be certified until May  6 00:29:27 2003 GMT (365 days)
Sign the certificate? [y/n]:y


1 out of 1 certificate requests certified, commit? [y/n]y
Write out database with 1 new entries
Data Base Updated
-------------------------------------------------------------------

-------------------------------------------------------------------
4.It sets "certificate and private key" to E-POST Mail Server".
-------------------------------------------------------------------
The made file
  mycert.pem ---- The certificate file
  mykey.pem ---- The private key file
It becomes.

Preserve in the optional folder and assign to Epstcontrol->[Server]->[SSL].

-------------------------------------------------------------------
5.The specification of the IP address for SMTP over SSL/the port (Client - Server)
-------------------------------------------------------------------
Epstcontrol-> Push [service]- >[EPSTRS Set IP] button.
The selection of "Replies to list's address" because a DIALOG display by "Set IP" is done.
Add SMTP server " IP address ", port ("25" and "465*").
Push "OK" button and re-start of SPARS.

note)
  It is possible to do coding communication when setting "MS-OE" in SSL.
  The other mail client will should use packet repeater "stone".

-------------------------------------------------------------------
6.The specification of the IP address for POP3 over SSL/the port (Client - Server)
-------------------------------------------------------------------
Epstcontrol-> Push [service]- >[EPSTRS Set IP] button.
The selection of "Replies to list's address" because a DIALOG display by "Set IP" is done.
Add SMTP server " IP address ", port ("110" and "995*").
Push "OK" button and re-start of SPAPOP3S.

note)
  It is possible to do coding communication when setting "MS-OE" in SSL.
  The other mail client will should use packet repeater "stone".

-------------------------------------------------------------------
7.The specification of the IP address for SMTP over SSL/the port (Server - Server)
-------------------------------------------------------------------
Epstcontrol->[Setup]->[Gateway table] It pushes a button.
Because the Gateway.dat file opens, it specifies and it preserves SMTP Server whose SSL communication according to the form is possible.

eg. It SMTP over SSLs a mail delivery for domain spa-mail.com.
   spa-mail.com,mail.e-postinc.jp,465*

-------------------------------------------------------------------
note)
* openssl.exe downloaded a sauce from http://www.openssl.org / and compiled it in VS2005.
* It edits openssl.cnf once more based on the distribution contents of http://www.openssl.org /.

